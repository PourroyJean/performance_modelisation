#!/bin/python2
# -*- coding: utf-8 -*-

import sys
import os
import operator

from xpworms import (engine, base_experiment, stats)
from execo_engine import (sweep, logger)


#
# Parameters (used in templates and in experiment preparation)
#

# sweep all possible parameter combination (one experiment per combination)
parameters = sweep({
    'algo_name': {
        "sum (0.6)": {
            'multiobj_algo': ["sum"],
            'factor': [0.6]
            },
        "sum (1)": {
            'multiobj_algo': ["sum"],
            'factor': [1]
            }
        },
    

    # factor is used as elec=(1-r) -- it=(r) for sinh and sum, and as fuzzy-margin for fuzzy-*
    #'factor' : [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 1],
    
    # internal coeficient for sinh-ext
    #'in_coef' : [2.5],

    # used to define which workload is used
    #'workload' : ['light', 'medium', 'smallSubset']
    #'workload' : ['medium', 'smallSubset']
    'workload' : ['testgen']
    })

# additional parameters, used in templates but not targeted by this serie
additionnal_params = {
#    'pv1_surface': 20
    }



# some charts :)
import matplotlib.pyplot as plt
import matplotlib.dates as md
import matplotlib.patches as mp
import dateutil
import scipy.interpolate
import numpy
import datetime

# dirtiest thing ever : manage UTC dates on my computer (UTC+2)
utcoffset = datetime.timedelta(hours=2)

def do_chart(filename, dcStats, panelStats):
    # not really elegant
    dc_x = []
    dc_y = []
    prev = None
    for measure in dcStats._data:
        # force 'stair'-like chart
        tms = measure._timestamp / 1000.0
        if prev is not None and prev[0] < tms - 1.0:
            dc_x.append(tms - 1.0)
            dc_y.append(prev[1])
        prev = (tms, measure._power)

        dc_x.append(tms)
        dc_y.append(measure._power)


    panel_x = []
    panel_y = []
    for measure in panelStats._data:
        panel_x.append(measure._timestamp / 1000.0)
        panel_y.append(measure._power)

    # get the same x axis (merge both)
    common_x = sorted(panel_x + list(set(dc_x) - set(panel_x)))

    # magic interpolation :)
    #dc_interpy = scipy.interpolate.interp1d(dc_x, dc_y, fill_value=(0.0, 0.0), bounds_error = False)
    #panel_interpy = scipy.interpolate.interp1d(panel_x, panel_y, fill_value=(0.0, 0.0), bounds_error = False)

    dc_interpy = numpy.interp(common_x, dc_x, dc_y, left=0.0, right=0.0)
    panel_interpy = numpy.interp(common_x, panel_x, panel_y, left=0.0, right=0.0)

    #plt.xkcd()
    fig1, ax1 = plt.subplots(1, 1)
    fig2, ax2 = plt.subplots(1, 1)
    fig3, ax3 = plt.subplots(1, 1)

    # transform timestamp into datetime for each x
    common_x2 = []
    for xval in common_x:
        common_x2.append(datetime.datetime.fromtimestamp(xval) - utcoffset)

    # format time...
    xfmt = md.DateFormatter('%H:%M')

    for (fig, ax) in [(fig1, ax1), (fig2, ax2), (fig3, ax3)]:
        ax.xaxis.set_major_formatter(xfmt)
        ax.grid()

        ax.set_title("Solar production and data center consumption")
        ax.set_xlabel(u"Time of day")
        ax.set_ylabel("Power [W]")


    # fig1 : only consumption
    ax1.plot(common_x2, dc_interpy, color='red')
    ax1.fill_between(common_x2, 0, dc_interpy, facecolor = 'red', alpha=0.3)
    ax1.set_title("Data center consumption")

    # fig2 : only consumption and production in an other color
    ax2.plot(common_x2, dc_interpy, color='red')
    ax2.fill_between(common_x2, 0, dc_interpy, facecolor = 'red', alpha=0.3)
    ax2.plot(common_x2, panel_interpy, color='blue')


    # fig3 : both and colorisation of differences between each!

    #ax.plot(dc_x, dc_y, panel_x, panel_y, color='black')
    ax3.plot(common_x2, dc_interpy, common_x2, panel_interpy, color='black')
    
    #ax.fill_between(dc_x, 0, dc_y, facecolor='red', alpha=0.6)
    ax3.fill_between(common_x2, panel_interpy, dc_interpy, where = panel_interpy < dc_interpy, facecolor = 'red', alpha=0.8)
    ax3.fill_between(common_x2, panel_interpy, dc_interpy, where = panel_interpy > dc_interpy, facecolor = 'blue', alpha=0.8)


    fig1.savefig(filename.format("conso"))
    fig2.savefig(filename.format("simpleAvailConso"))
    fig3.savefig(filename.format("availConso"))


def dater_to_nums(date, timed):
    d2 = date + timed
    return (md.date2num(date), md.date2num(d2) - md.date2num(date))

def obj_to_color(obj):
    return "#{0:06x}".format(hash(hash(obj)*hash(obj)) % (1 << 24) )


def do_task_chart(filename, tasks):
    # get task list for each proc
    proc_tasks = {}
    for t in tasks._data:
        if t._proc_name not in proc_tasks:
            proc_tasks[t._proc_name] = []
        proc_tasks[t._proc_name].append(t)

    # not pretty at all :)
    procs = {}
    for n in range(1, 7):
        procs[n] = {'values': [], 'colors': [], 'names': [], 'tasks': []}

    # NOT generic at ALL!
    anydate = None

    # fill the proc list with tasks pairs (begin, exec_time)
    for key in proc_tasks:
        # get the proc number (not generic, format expected is "[some/thing/Proc_N]")
        procnb = int(key[-2:-1])
        #proc = "Noeud {}".format(procnb)

        for t in proc_tasks[key]:
            datet = datetime.datetime.fromtimestamp(t._exec_date) - utcoffset
            timet = datetime.timedelta(seconds = t._exec_time)
            procs[procnb]['values'].append( dater_to_nums(datet, timet) )

            # FIXME not generic at all : add information for a specific job...
            if t._job_id == 0 and t._task_id == 5:
                procs[procnb]['colors'].append( 'red' )
            else:
                procs[procnb]['colors'].append( obj_to_color((t._job_id, t._task_id)) )
            procs[procnb]['names'].append( "{}_{}".format(t._job_id, t._task_id) )
            procs[procnb]['tasks'].append( t )
            anydate = datet


    fig, ax = plt.subplots(1, 1)


    # insert the items...
    labels = []
    yticks = []
    for n in range(1, 7):
        labels.append("Machine {}".format(n))
        cury = 3.5 + 10*n
        yticks.append(cury)
        rects = ax.broken_barh(procs[n]['values'], (10*n, 7), facecolor=procs[n]['colors'])

        # print some labels?
        for i in range(0, len(procs[n]['values'])):
            (valb, vallen) = procs[n]['values'][i]
            name = procs[n]['names'][i]
            valmid = valb + vallen/2
            # FIXME arbitrary value, more or less 1h, but not significant for real size...
            if vallen > 0.04:
                ax.text(valmid, cury, name, horizontalalignment='center',
                        verticalalignment='center', color='black', clip_on=True)

            # FIXME not generic at all : add information for a specific job...
            if name == "0_5":
                deadval = md.date2num(datetime.datetime.fromtimestamp(procs[n]['tasks'][i]._deadline_date) - utcoffset)
                subval = md.date2num(datetime.datetime.fromtimestamp(procs[n]['tasks'][i]._sub_date) - utcoffset)
                valend = valb+vallen
                patch = mp.Rectangle( (subval, cury-2), deadval - subval - 0.005, 4.0,
                #patch = mp.Rectangle( (valend, cury-2), deadval - valend - 0.005, 4.0,
                        facecolor='green', alpha=0.9, hatch='///', zorder=-1)
                ax.add_patch(patch)





    ax.set_yticks(yticks)
    ax.set_yticklabels(labels)

    # format time...
    xfmt = md.DateFormatter('%H:%M')
    ax.xaxis.set_major_formatter(xfmt)

    # some black magic to force a 5h00 - 17h30 window
    dstart = anydate.replace(hour = 5, minute = 0, second = 0, microsecond=0)
    dend = anydate.replace(hour = 17, minute = 30, second = 0, microsecond=0)

    ax.set_xlim(dstart, dend)
    ax.set_ylim(9, 70)

    ax.grid(True)
    ax.set_axisbelow(True)

    ax.set_title(u"Task executed on each machine")
    ax.set_xlabel(u"Time of day")

    fig.savefig(filename)



globalStats = {}

def get_stats_keeper(key = None):
    """
    Get the StatsKeeper object corresponding to the given key, or create it
    if needed. If key is None, the returned one is associated with key "_all_".
    """
    if key is None:
        key = "_all_"

    global globalStats
    if key in globalStats:
        return globalStats[key]
    else:
        globalStats[key] = stats.StatsKeeper()
        return globalStats[key]



def stats_expe(idir, odir, params):
    logger.info("Processing experiment stats, for parameters : {}".format(str(params)) )
    sitem = {}

    gridStats = stats.parse_electrical_stats(os.path.join(odir, 'Simulation_1_Electrical/gridSource_Consumed/Consumed_power_at_output_gridSource_output') )
    dcPowerStats = stats.parse_electrical_stats(os.path.join(odir, 'Simulation_1_Electrical/dataCenterSupply_Consumed/Consumed_power_from_input_dataCenterSupply_input') )

    # FIXME temp :
    panelStats = stats.parse_electrical_stats(os.path.join(odir, 'Simulation_1_Electrical/photovoltalicPanel_Available/Available_power_to_output_photovoltalicPanel_output') )
    do_chart(os.path.join(odir, "{}_chart.pdf"), dcPowerStats, panelStats)


    # trust the deadlines as we provide tasks with advance reservation info
    # (only for smallSubset, other don't have reservation data!)
    should_trust = False
    if params['workload'] == 'smallSubset' or params['workload'] == 'testgen':
        should_trust = True
    taskStats = stats.parse_task_stats(os.path.join(odir, 'Stats_Simulation_1_Tasks.txt'),
            trust_deadline = should_trust)

    # FIXME temp :
    do_task_chart(os.path.join(odir, "task_chart.pdf"), taskStats)

    sitem['Grid Ratio'] = gridStats.total_energy() / dcPowerStats.total_energy()
    sitem['Waiting Ratio'] = taskStats.mean_margin()
    sitem['Total energy'] = dcPowerStats.total_energy()
    sitem['Missed Ratio'] = taskStats.outdated_ratio()

    #sitem['Fuzzy Margin'] = params['fuzzy_margin']

    #sitem['Weight IT'] = params['weight_it']
    #sitem['Weight Elec'] = params['weight_elec']
    #sitem['Weight Ratio'] = params['weight_elec'] / float(params['weight_it'])
    #sitem['Ratio'] = params['factor']

    # info needed for transform_data()
    sitem['algo'] = params['algo_name']

    wl2serie = {
            'light': 'Std. Wl Light',
            'medium': 'Std. Wl Medium',
            'smallSubset': 'Small Subset',
            'testgen' : 'PyWlGen test'
            }
    sitem['testset'] = wl2serie.get(params['workload'], 'Unknown')

    # add item to given stats
    #key = params['multiobj_algo'] + '_wl-' + params['workload']
    #get_stats_keeper(key).add_item(sitem)

    # we will sort the stats latter...
    get_stats_keeper().add_item(sitem)




class MyExperiment(base_experiment.BaseExperiment):
    def init(self):
        base_experiment.BaseExperiment.init(self)

        # find the appropriate (resources, workload) pair

        wltype = self.template_params['workload']

        if wltype == "smallSubset" or wltype == 'testgen':
            rsctype = 'smallSubsetResources'
            jobtype = 'XMLJobs'
        else:
            rsctype = 'defaultResources'
            jobtype = 'SWFOnly'

        # workload directory
        wlorig = "workload_{}".format(wltype)

        # resource file
        rscorig = "{}.xml".format(rsctype)

        # properties file, used to define either SWF+XML jobs or SWF only
        proporig = "experiment{}.properties".format(jobtype)

        # copy the appropriate 'workload_xxx' dir into 'workload'
        self.input_files = [(wlorig, 'workload')]
        # copy templates for resource and properties
        self.template_files = [(rscorig, 'resources.xml'), (proporig, 'experiment.properties')]

    def process_results(self):
        stats_expe(self.experiment_dir, self.result_dir, self.template_params)



inputPath = os.path.join(os.getcwd(), 'multiExperiments')
theEngine = engine.Engine(parameters, experiment_class = MyExperiment,
        input_dir = inputPath, additionnal_params = additionnal_params)
theEngine.start(sys.argv)


# we need some ordering...
#for statsName in globalStats:
#    theStats = globalStats[statsName]
#    theStats.items.sort(key=operator.itemgetter('Ratio')) 
#    theStats.write_dat_file(os.path.join(theEngine.output_dir, "stats_{:.3g}.dat".format(statsName)),
#            ['Ratio', 'Waiting Ratio', 'Missed Ratio', 'Grid Ratio', 'Total energy'])

# transform data into several datasets to compare the different algorithms
for stat in ['Grid Ratio', 'Waiting Ratio', 'Missed Ratio', 'Total energy']:
    gridStats = get_stats_keeper().transform_data(
            get_serie = operator.itemgetter("testset"),
            get_category = operator.itemgetter("algo"),
            get_value = operator.itemgetter(stat) )
    filename = "stats_{}.dat".format(stat.lower().replace(" ", "-"))
    gridStats.write_dat_file(os.path.join(theEngine.output_dir, filename), comment_header = False)

