How to re-run this experiment?
=================================

To re-run this experiment, get the appropriate versions of DCWoRMS, xpworms and
a working python2 (>= 2.6) environment. Java environment is also requiered to
run DCWoRMS, along with apache ant.

Set `PYTHONPATH` env variable to add the path to xpworms repository, like (bash) :
```
export PYTHONPATH="/path/to/xpworms:$PYTHONPATH"
```

The DCWoRMS path may be given either by setting env variable `DCWORMS_PATH`, or
by providing it as an argument to the experiment script using `--dcworms-path=...`
option.

Then, ensure you are in the directory where 'main.py' is, and run the experiment :
```
python2 main.py --dcworms-path="/path/to/DCWoRMS"
```
You can change the output directory by appending '-c "/path/to/output/dir"'.



Which revision of DCWoRMS and xpworms is needed?
--------------------------------------------------
If you're lucky, the following lines should contains the DCWoRMS and xpworms
revisions used when this experiment was initialy ran.
It is __highly__ recommanded to get the Git repositories and to checkout the
indicated revisions...


* DCWoRMS (git) : 286d5d41e6471516a1cb86687bcdf39915993fad-dirty
* xpworms (git) : 9d1ae15cef560ac949c116536fade2274bf7c5b0-dirty


Notes
-------
Date : 2016-06-02T22:11:49.290448